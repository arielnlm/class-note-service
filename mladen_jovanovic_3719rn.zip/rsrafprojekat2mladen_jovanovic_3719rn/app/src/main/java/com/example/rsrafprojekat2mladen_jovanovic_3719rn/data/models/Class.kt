package com.example.rsrafprojekat2mladen_jovanovic_3719rn.data.models

data class Class(
    val id: Int? = null,
    val subject: String,
    val type: String,
    val teacher: String,
    val groups: String,
    val day: String,
    val time: String,
    val classroom: String
)
